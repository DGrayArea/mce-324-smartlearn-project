## What technologies are used for this project?

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

# Student:

`student@demo.com`

# Lecturer:

`lecturer@demo.com`

# Admin:

`admin@demo.com`

# Password for all demo accounts:

`password123`
