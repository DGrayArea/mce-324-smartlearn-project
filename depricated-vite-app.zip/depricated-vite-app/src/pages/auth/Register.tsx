import { RegisterForm } from '@/components/auth/RegisterForm';

const Register = () => {
  return <RegisterForm />;
};

export default Register;