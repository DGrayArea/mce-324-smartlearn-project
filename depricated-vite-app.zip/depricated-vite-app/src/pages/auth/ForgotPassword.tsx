import { ForgotPasswordForm } from '@/components/auth/ForgotPasswordForm';

const ForgotPassword = () => {
  return <ForgotPasswordForm />;
};

export default ForgotPassword;